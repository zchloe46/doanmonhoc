# doanmonhoc
bước 1: tạo project với Django trên Pycharm<br>
bước 2: tải các thư viện hỗ trợ<br>
    $ pip install underthesea<br>
    $ pip install pymysql<br>
bước 3: mở server trên Pycharm<br>
    cd đến thư mục chứa manage.py<br>
    $ python manage.py runserver<br>
<img alt="img.png" height="300" src="img.png" width="500"/><br>
bước 4: truy cập vào trình duyệt và gõ địa chỉ http://127.0.0.1:8000/<br>
